OVERVIEW

- Exe is portable and can be placed wherever you need it.

- Make sure to run as admin so that the key presses are propagated to Hll.

- On first setup, be sure to set your resolution in the settings.

- The sliders set the target values of the actions, which are then executed with hotkeys.

- Hotkey reference can be found in the info panel.

- Actions execute as macros, so make sure that you're not pressing any keys or 
	moving the mouse while they execute.

HOTKEYS

Proximity:

Right Alt + ,	........  Set to 0
Right Alt + l	........  Set to Low Target Value
Right Alt + p	........  Set to High Target Value

Unit:

Right Alt + .	........  Set to 0
Right Alt + ;	........  Set to Low Target Value
Right Alt + [	........  Set to High Target Value

Leadership:

Right Alt + /	........  Set to 0
Right Alt + '	........  Set to Low Target Value
Right Alt + ]	........  Set to High Target Value